import { Component, OnInit } from '@angular/core';
import { S1Service } from '../s1.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-proinfo',
  templateUrl: './proinfo.component.html',
  styleUrls: ['./proinfo.component.css']
})
export class ProinfoComponent implements OnInit {
var_pid;
  constructor(private ser:S1Service,private rt:ActivatedRoute) {
    this.rt.params.subscribe((dt)=>{
      this.var_pid=dt.proid
    })
   }

  ngOnInit() {
  }

}
